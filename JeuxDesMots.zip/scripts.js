let total=0;
let mot_deja_utiliser=[]


function number_of_letters(word){
	//cette fonction compte le nombre de lettre dans le mots
	return word.length
}

function number_of_consonne(word){
	//cette fonction compte le nombre de consonne dans le mots
	let consonne=['B','C','D','F','G','H','J','K','L','M','N','P','Q','R','S','T','V','W','X','Y','Z']
	let numbr_ltr=0;
	for(var i=0; i<word.length; i++){
		if(consonne.includes(word[i].toUpperCase())){
			numbr_ltr+=1;
		}
	}
	return numbr_ltr
}

function culculate_point(word){
	//cette fonction calcul les points en fonction du mot
	let numbr_ltr=0;
	let cotation=[{
		'points':1,
		'lettres':['e','a','i','n','o','r','s','t','l']
	},
	{
		'points':2,
		'lettres':['d','g','m']
	},
	{
		'points':3,
		'lettres':['b','c','p']
	},
	{
		'points':4,
		'lettres':['f','h','v']
	},
	{
		'points':8,
		'lettres':['j','q']
	},
	{
		'points':10,
		'lettres':['k','w','x','y','z']
	},
	]


	for(let i=0; i<word.length; i++){
		for(let j=0; j<cotation.length; j++){
			if(cotation[j].lettres.includes(word[i].toLowerCase())){
				numbr_ltr+=cotation[j].points;
			}
		}
	}
	return numbr_ltr
}

function total_add_to(points){
	total+=points;
	return total
}

function jeux(){
	let word_list=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
	let max_length=20;
	let is_succed_user=false;
	let indice=Math.random() * (26 - 0) + 0;
	indice=String(indice).split(".")[0]
	indice=parseInt(indice)
	let random_letter=word_list[indice]
	do{
		
		let user_input=prompt(`Entrer un mot de 1 a ${max_length} lettres debutant par ${random_letter}`)
		//on teste si l'utilisateur a reussi
		user_input=user_input.trim()
		if(user_input.startsWith(random_letter) && user_input.length<=max_length){
			//verifie si le mot n'est pas deja utiliser precedement
			if(mot_deja_utiliser.includes(user_input)){
				alert("Ce mot a deja utilise dans le questions precedente....ressayer avec un autre!")
				continue;
			}
			//she succed
			is_succed_user=true;
			let affiche_box=document.querySelector('.central-block')
			//Ecriture des informations dans le box
			affiche_box.innerHTML=`\
				<table>\
					<tr>
						<td>Mot </td>\
						<td>: ${user_input.toUpperCase()}</td>\
					</tr>
					<tr>
						<td>Lettres </td>\
						<td>: ${number_of_letters(user_input)}</td>
					</tr>

					<tr>
						<td>Consonnes </td>\
						<td>: ${number_of_consonne(user_input)}</td>
					</tr>

					<tr>
						<td>Points </td>\
						<td>: ${culculate_point(user_input)}</td>
					</tr>

					<tr>
						<td>Points </td>\
						<td>: ${total_add_to(culculate_point(user_input))}</td>
					</tr>

				</table>\
			`
			mot_deja_utiliser.push(user_input)
			console.log(mot_deja_utiliser)
			if(total > 200){
				total=0
				document.querySelector('.btn').setAttribute('disabled','disabled')
				document.querySelector('.finish').classList.remove("d-none")
				return 0
				}

			
		}

	}while(!is_succed_user);
	
}